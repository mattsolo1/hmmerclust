hmmerclust
==========

A python package for detection and analysis of gene clusters in bacterial genomes.


