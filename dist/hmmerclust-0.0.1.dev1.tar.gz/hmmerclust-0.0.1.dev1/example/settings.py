
color_brown = 'brown'
color_blue = 'blue'
color_green = 'green'
color_yellow = 'yellow'
color_purple = 'purple'
color_maroon = '#660033'
color_teal = '#00FFCC'
color_dark_grey = '#404040'
wdomain = '#FFCC99'
ydomain = '#FFCC66'
chaperone = '#99CC00' #lime
'''
cdict = {'EccC' : color_brown,
        'EccD' : color_green,
        'MycP' : color_yellow,
        'EccB' : color_blue,
        'EccA' : color_teal,
        'EccE' : color_purple,
        'WXG100' : wdomain,
        'PE' : ydomain,
        'PPE': wdomain,
        'DUF2563' : ydomain, 
        'DUF2580' : ydomain,
        'EspA' : wdomain,
        'EspB' : wdomain,
        'EspC' : ydomain,
        'EspE' : wdomain,
        'EspF' : ydomain,
        'EspJ' : ydomain,
        'EspK' : wdomain,
        'EspL' : color_dark_grey,
        'EspD' : chaperone,
        'EspG' : chaperone,
        'EspI' : color_dark_grey,
        }
'''

hmcol = ['InvE',
        'InvC',
        'SpaP',
        'SpaQ',
        'SpaR',
        'SpaS',
        'InvA',
        'SpaO',
        'OrgB',
        'OrgA',
        'PrgK',
        'PrgH',
        'InvG',
        'InvH',
        'FlgH',
        'PrgI',
        'PrgJ',
        'InvJ',
        'SipC',
        'SipB',
        'SipD']